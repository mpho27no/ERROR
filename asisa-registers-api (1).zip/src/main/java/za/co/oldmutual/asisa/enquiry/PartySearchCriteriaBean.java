package za.co.oldmutual.asisa.enquiry;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PartySearchCriteriaBean {

	private String partyID;

}
