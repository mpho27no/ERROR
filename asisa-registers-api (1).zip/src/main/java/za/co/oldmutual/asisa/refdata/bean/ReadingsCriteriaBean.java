package za.co.oldmutual.asisa.refdata.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReadingsCriteriaBean {

	private String code;
	
	private String impairmentCode;
	
	private String format;
	
}
