package za.co.oldmutual.asisa.refdata.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OfficeBean {

	private String id;
	
	private String locationID;
	
	private String officeID;
	
	private String description;
	
	private String name;
}
