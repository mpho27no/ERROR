package za.co.oldmutual.asisa.common.bean;

public enum OperationTypeEnum {
CREATE,UPDATE,DELETE,UPDATE_REJECT,DELETE_REJECT
}
