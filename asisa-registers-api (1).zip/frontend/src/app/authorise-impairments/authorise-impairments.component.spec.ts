import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthoriseImpairmentsComponent } from './authorise-impairments.component';

// describe('AuthoriseImpairmentsComponent', () => {
//   let component: AuthoriseImpairmentsComponent;
//   let fixture: ComponentFixture<AuthoriseImpairmentsComponent>;

//   // beforeEach(async(() => {
//   //   TestBed.configureTestingModule({
//   //     declarations: [ AuthoriseImpairmentsComponent ]
//   //   })
//   //   .compileComponents();
//   // }));

//   // beforeEach(() => {
//   //   fixture = TestBed.createComponent(AuthoriseImpairmentsComponent);
//   //   component = fixture.componentInstance;
//   //   fixture.detectChanges();
//   // });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
