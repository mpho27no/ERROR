export interface PaymentMethod {
    description: string;
    code: string;
}
