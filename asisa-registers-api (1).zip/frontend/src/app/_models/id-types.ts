export class IdTypes {
    code: string;
    description: string;
}
