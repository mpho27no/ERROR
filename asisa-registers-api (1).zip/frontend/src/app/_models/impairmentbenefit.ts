export interface Impairmentbenefit {
    description: string;
    code: string;
    claimType: string;
}
