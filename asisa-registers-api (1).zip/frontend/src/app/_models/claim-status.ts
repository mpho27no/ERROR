export interface ClaimStatus {
    description: string;
    code: string;
}
