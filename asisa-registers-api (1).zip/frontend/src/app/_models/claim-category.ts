export interface ClaimCategory {
    code: string;
    description: string;
    claimType: string;
}
