export interface Pretitle {
    description: string;
    code: string;
}
