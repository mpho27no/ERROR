export interface SpecialInvestigate {
    description: string;
    code: string;
}
