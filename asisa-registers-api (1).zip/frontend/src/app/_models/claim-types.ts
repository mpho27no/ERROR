export interface ClaimTypes {
    description: string;
    code: string;
}
