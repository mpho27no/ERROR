export interface ClaimReason {
    description: string;
    code: string;
    impairmentCodeGroupId: string;
}
