export interface CauseOfEvents {
    code: string;
    description: string;
}
