export interface Symbol {
    description: string;
    code: string;
}
