export interface Gender {
    code: string;
    description: string;
}


