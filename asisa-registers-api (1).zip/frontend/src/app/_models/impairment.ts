export interface Impairment {
    description: string;
    code: string;
    impairmentCodeGroupId: string;
    codes?: any;
}
