import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScratchpadHistoryComponent } from './scratchpad-history.component';

// describe('ScratchpadHistoryComponent', () => {
//   let component: ScratchpadHistoryComponent;
//   let fixture: ComponentFixture<ScratchpadHistoryComponent>;

//   // beforeEach(async(() => {
//   //   TestBed.configureTestingModule({
//   //     declarations: [ ScratchpadHistoryComponent ]
//   //   })
//   //   .compileComponents();
//   // }));

//   // beforeEach(() => {
//   //   fixture = TestBed.createComponent(ScratchpadHistoryComponent);
//   //   component = fixture.componentInstance;
//   //   fixture.detectChanges();
//   // });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
