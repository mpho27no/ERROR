import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InsuredPersonDetailsComponent } from './insured-person-details.component';

// describe('InsuredPersonDetailsComponent', () => {
//   let component: InsuredPersonDetailsComponent;
//   let fixture: ComponentFixture<InsuredPersonDetailsComponent>;

//   // beforeEach(async(() => {
//   //   TestBed.configureTestingModule({
//   //     declarations: [ InsuredPersonDetailsComponent ]
//   //   })
//   //   .compileComponents();
//   // }));

//   // beforeEach(() => {
//   //   fixture = TestBed.createComponent(InsuredPersonDetailsComponent);
//   //   component = fixture.componentInstance;
//   //   fixture.detectChanges();
//   // });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
