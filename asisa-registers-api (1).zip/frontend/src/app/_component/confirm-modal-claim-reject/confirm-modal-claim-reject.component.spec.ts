import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmModalClaimRejectComponent } from './confirm-modal-claim-reject.component';

// describe('ConfirmModalClaimRejectComponent', () => {
//   let component: ConfirmModalClaimRejectComponent;
//   let fixture: ComponentFixture<ConfirmModalClaimRejectComponent>;

//   // beforeEach(async(() => {
//   //   TestBed.configureTestingModule({
//   //     declarations: [ ConfirmModalClaimRejectComponent ]
//   //   })
//   //   .compileComponents();
//   // }));

//   // beforeEach(() => {
//   //   fixture = TestBed.createComponent(ConfirmModalClaimRejectComponent);
//   //   component = fixture.componentInstance;
//   //   fixture.detectChanges();
//   // });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
