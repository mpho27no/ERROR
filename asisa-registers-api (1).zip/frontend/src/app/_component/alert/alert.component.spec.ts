import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlertComponent } from './alert.component';

// describe('AlertComponent', () => {

//     beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [
//         AlertComponent
//       ],
//     }).compileComponents();
//   }));

//   it('should create the AlertComponent', () => {
//     const fixture = TestBed.createComponent(AlertComponent);
//     const app = fixture.debugElement.componentInstance;
//     expect(app).toBeTruthy();
//   });
  // let component: AlertComponent;
  // // let fixture: ComponentFixture<AlertComponent>;
  // beforeEach(() => TestBed.configureTestingModule({}));

  //   it('should be created', () => {
  //   const service: TestService = TestBed.get(TestService);
  //   expect(service).toBeTruthy();
  // });

  // beforeEach(async(() => {
  //   TestBed.configureTestingModule({
  //     declarations: [ AlertComponent ]
  //   })
  //   .compileComponents();
  // }));

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(AlertComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
// });
