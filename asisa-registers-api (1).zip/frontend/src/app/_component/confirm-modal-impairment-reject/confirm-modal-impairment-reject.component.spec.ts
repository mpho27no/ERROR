import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmModalImpairmentRejectComponent } from './confirm-modal-impairment-reject.component';

// describe('ConfirmModalImpairmentRejectComponent', () => {
//   let component: ConfirmModalImpairmentRejectComponent;
//   let fixture: ComponentFixture<ConfirmModalImpairmentRejectComponent>;

//   // beforeEach(async(() => {
//   //   TestBed.configureTestingModule({
//   //     declarations: [ ConfirmModalImpairmentRejectComponent ]
//   //   })
//   //   .compileComponents();
//   // }));

//   // beforeEach(() => {
//   //   fixture = TestBed.createComponent(ConfirmModalImpairmentRejectComponent);
//   //   component = fixture.componentInstance;
//   //   fixture.detectChanges();
//   // });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
