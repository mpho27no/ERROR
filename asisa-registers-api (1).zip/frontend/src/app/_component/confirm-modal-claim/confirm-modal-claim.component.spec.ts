import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmModalClaimComponent } from './confirm-modal-claim.component';

// describe('ConfirmModalClaimComponent', () => {
//   let component: ConfirmModalClaimComponent;
//   let fixture: ComponentFixture<ConfirmModalClaimComponent>;

//   // beforeEach(async(() => {
//   //   TestBed.configureTestingModule({
//   //     declarations: [ ConfirmModalClaimComponent ]
//   //   })
//   //   .compileComponents();
//   // }));

//   // beforeEach(() => {
//   //   fixture = TestBed.createComponent(ConfirmModalClaimComponent);
//   //   component = fixture.componentInstance;
//   //   fixture.detectChanges();
//   // });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
