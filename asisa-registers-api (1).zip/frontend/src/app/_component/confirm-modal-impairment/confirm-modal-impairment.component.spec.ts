import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmModalImpairmentComponent } from './confirm-modal-impairment.component';

// describe('ConfirmModalImpairmentComponent', () => {
//   let component: ConfirmModalImpairmentComponent;
//   let fixture: ComponentFixture<ConfirmModalImpairmentComponent>;

//   // beforeEach(async(() => {
//   //   TestBed.configureTestingModule({
//   //     declarations: [ ConfirmModalImpairmentComponent ]
//   //   })
//   //   .compileComponents();
//   // }));

//   // beforeEach(() => {
//   //   fixture = TestBed.createComponent(ConfirmModalImpairmentComponent);
//   //   component = fixture.componentInstance;
//   //   fixture.detectChanges();
//   // });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
