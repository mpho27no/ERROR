// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { AuthorizeImpairmentListComponent } from './authorize-impairment-list.component';

// describe('AuthorizeImpairmentListComponent', () => {
//   let component: AuthorizeImpairmentListComponent;
//   let fixture: ComponentFixture<AuthorizeImpairmentListComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ AuthorizeImpairmentListComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AuthorizeImpairmentListComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
