import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InsuredPersonEnquiryComponent } from './insured-person-enquiry.component';

// describe('InsuredPersonEnquiryComponent', () => {
//   let component: InsuredPersonEnquiryComponent;
//   let fixture: ComponentFixture<InsuredPersonEnquiryComponent>;

//   // beforeEach(async(() => {
//   //   TestBed.configureTestingModule({
//   //     declarations: [ InsuredPersonEnquiryComponent ]
//   //   })
//   //   .compileComponents();
//   // }));

//   // beforeEach(() => {
//   //   fixture = TestBed.createComponent(InsuredPersonEnquiryComponent);
//   //   component = fixture.componentInstance;
//   //   fixture.detectChanges();
//   // });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
