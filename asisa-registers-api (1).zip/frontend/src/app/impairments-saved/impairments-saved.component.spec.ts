import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImpairmentsSavedComponent } from './impairments-saved.component';

// describe('ImpairmentsSavedComponent', () => {
//   let component: ImpairmentsSavedComponent;
//   let fixture: ComponentFixture<ImpairmentsSavedComponent>;

//   // beforeEach(async(() => {
//   //   TestBed.configureTestingModule({
//   //     declarations: [ ImpairmentsSavedComponent ]
//   //   })
//   //   .compileComponents();
//   // }));

//   // beforeEach(() => {
//   //   fixture = TestBed.createComponent(ImpairmentsSavedComponent);
//   //   component = fixture.componentInstance;
//   //   fixture.detectChanges();
//   // });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
