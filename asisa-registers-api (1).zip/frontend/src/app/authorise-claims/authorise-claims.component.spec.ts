import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthoriseClaimsComponent } from './authorise-claims.component';

// describe('AuthoriseClaimsComponent', () => {
//   let component: AuthoriseClaimsComponent;
//   let fixture: ComponentFixture<AuthoriseClaimsComponent>;

//   // beforeEach(async(() => {
//   //   TestBed.configureTestingModule({
//   //     declarations: [ AuthoriseClaimsComponent ]
//   //   })
//   //   .compileComponents();
//   // }));

//   // beforeEach(() => {
//   //   fixture = TestBed.createComponent(AuthoriseClaimsComponent);
//   //   component = fixture.componentInstance;
//   //   fixture.detectChanges();
//   // });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
