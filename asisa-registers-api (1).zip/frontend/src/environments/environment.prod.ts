export const environment = {
  production: true,
  apiEndpoint: './api',
  //  apiEndpoint: 'http://localhost:8080/api',
   // apiEndpoint: 'https://asisa-registers-dit-api.app.ocp.dr.za.omlac.net/api',
  gcsEndpoint: 'https://apigwint.dev.za.omlac.net/omem/dev-int/insurance/life/party/v9/persons'
};
